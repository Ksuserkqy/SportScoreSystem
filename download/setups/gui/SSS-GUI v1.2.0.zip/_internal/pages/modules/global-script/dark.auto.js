function toggleDarkMode() {
    const now = new Date().getHours();
    const startDarkModeAt = 22; // 晚上10点开始暗黑模式
    const endDarkModeAt = 7;   // 早上7点结束暗黑模式
   
    // 检查当前时间，并开启或关闭暗黑模式
    if (now >= startDarkModeAt && now <= endDarkModeAt) {
      // 开启暗黑模式的逻辑
      document.body.classList.add('dark-mode');
    } else {
      // 关闭暗黑模式的逻辑
      document.body.classList.remove('dark-mode');
    }
  }

toggleDarkMode()